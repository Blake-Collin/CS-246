/**
 * ENUM for Destinations
 *
 * @author Collin Blake
 * @since 04-29-2019
 */
enum Destination {
  Mexico,
  Europe,
  Japan
}
